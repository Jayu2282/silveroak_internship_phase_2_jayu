function myfuncetion()
{
    a=document.getElementById("mytext")[0];
    alert(a.value);
}