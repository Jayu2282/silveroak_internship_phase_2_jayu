function myAlert(msg){
    if(confirm("are you sure you want to display the message?????")){alert(msg);
}
else
{
    
    alert("messge not displayed as user canceled opretion");
}
}
